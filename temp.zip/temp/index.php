<?php require_once('config.php') ?>
<?php require_once('includes/headsection.php') ?>

	<title>LifeBlog | Home </title>
</head>
<body>
	<!-- container - wraps whole page -->
	<div class="container">
		<!-- navbar -->
		<?php require_once('includes/navbar.php') ?>
		<!-- // navbar -->

		<!-- Page content -->
		<div class="content">
			<h2 class="content-title">Recent Articles</h2>
			<hr>
			<!-- more content still to come here ... -->
		</div>

        <!-- Banner -->
        <?php require_once('includes/banner.php') ?>

		<!-- // Page content -->

		<!-- footer -->
		<?php require_once('includes/footer.php') ?>