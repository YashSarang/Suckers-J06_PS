<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/project_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
</head>
<body>
    <!-- This banner is not part of plugin. -->
<section class="coursesgrid-banner">
    <h1>Brand Name</h1>
</section>

<!-- Begin block -->
<div class="block_coursesgrid">

    <section class="coursesgrid-search">
        <form role="search" aria-label="Course Catalog">
            <label for='course-search-box'>
                <span class='sr-only'>Searchbox</span>
            </label>

            <input type='text' id='course-search-box' placeholder="Explore Courses" />

            <button type='submit'>
                Search
                <span class='sr-only'>Submit Search</span>
            </button>
        </form>
    </section>

    <section class="coursesgrid-wrap">

        <aside class="coursesgrid-filters">
            <fieldset>
                <legend>Filter Courses</legend>
                <div class="filter-wrap">
                    <input type="checkbox" name="Label One" id="label-one" value="1">
                    <label for="label-one">Filter One</label>
                </div>
                <div class="filter-wrap">
                    <input type="checkbox" name="Label Two" id="label-two" value="1">
                    <label for="label-two">Filter Two</label>
                </div>
                <div class="filter-wrap">
                    <input type="checkbox" name="Label Three" id="label-three" value="1">
                    <label for="label-three">Filter Three</label>
                </div>
                <div class="filter-wrap">
                    <input type="checkbox" name="Label Four" id="label-four" value="1">
                    <label for="label-four">Filter Four</label>
                </div>
                <div class="filter-wrap">
                    <input type="checkbox" name="Label Five" id="label-five" value="1">
                    <label for="label-five">Filter Five</label>
                </div>
            </fieldset>
        </aside>

        <div class="coursesgrid-panels">
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/pfX-GsJMtDY/200x100/">
                    <div class="panel-type panel-type-other">
                        <span class="fa fa-star"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">200 x 100px - 2:1</span>
                    <h3>Course Title</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus. Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/pfX-GsJMtDY/400x200/">
                    <div class="panel-type panel-type-video">
                        <span class="fa fa-video-camera"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">400 x 200px - 2:1</span>
                    <h3>Course title lorem ipsum dolor sit amet</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/pfX-GsJMtDY/600x300/">
                    <div class="panel-type panel-type-course">
                        <span class="fa fa-file-text-o"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">600 x 300px - 2:1</span>
                    <h3>Course Title</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/pfX-GsJMtDY/800x400/">
                    <div class="panel-type panel-type-video">
                        <span class="fa fa-video-camera"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">800 x 400px - 2:1</span>
                    <h3>Course Title</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/g1Kr4Ozfoac/250x125/">
                    <div class="panel-type panel-type-course">
                        <span class="fa fa-file-text-o"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">250 x 125px - 2:1</span>
                    <h3>Course Title</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/g1Kr4Ozfoac/400x200/">
                    <div class="panel-type panel-type-other">
                        <span class="fa fa-star"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">400 x 200 - 2:1</span>
                    <h3>Course Title</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/g1Kr4Ozfoac/600x300/">
                    <div class="panel-type panel-type-video">
                        <span class="fa fa-video-camera"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">600 x 300px - 2:1</span>
                    <h3>Course Title</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/g1Kr4Ozfoac/800x400/">
                    <div class="panel-type panel-type-other">
                        <span class="fa fa-star"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">800 x 400 - 2:1</span>
                    <h3>Course Title</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/pfX-GsJMtDY/300x150/">
                    <div class="panel-type panel-type-other">
                        <span class="fa fa-star"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">300 x 150px - 2:1</span>
                    <h3>Course Title</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
            <a class="panel panel-default">
                <div class="panel-img">
                    <img src="https://source.unsplash.com/pfX-GsJMtDY/1000x500/">
                    <div class="panel-type panel-type-video">
                        <span class="fa fa-video-camera"></span>
                    </div>
                </div>
                <div class="panel-body">
                    <span class="panel-eyebrow">1000 x 500px - 2:1</span>
                    <h3>Course Title</h3>
                    <p>Course summary, lorem ipsum dolor sit amet. Maecenas ultrices tortor a lectus venenatis, quis efficitur justo rhoncus.</p>
                </div>
                <span class="panel-data">Course data here...</span>
            </a>
        </div>

    </section>

</div>
</body>
</html>
