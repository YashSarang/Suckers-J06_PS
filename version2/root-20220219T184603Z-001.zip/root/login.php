<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="images/logo.png" type="image/ico">
  <link rel="stylesheet" href="css/login_style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link href='https://fonts.googleapis.com/css?family=Roboto:400,300,100' rel='stylesheet' type='text/css'>
  <title>Vesit Project Showcase | Login/Signup</title>
</head>
<body>

  <div class="container">
    <div class="backbox">
      <div class="loginMsg">
        <div class="textcontent">
          <p class="title">Don't have an account?</p>
          <p>Sign up to save all your graph.</p>
          <button id="switch1">Sign Up</button>
        </div>
      </div>
      <div class="signupMsg visibility">
        <div class="textcontent">
          <p class="title">Have an account?</p>
          <p>Log in to see all your collection.</p>
          <button id="switch2">LOG IN</button>
        </div>
      </div>
    </div>
    <!-- backbox -->

    <form action="includes/login-signup.inc.php" method="post">
    <div class="frontbox">
      <div class="login">
        <h2>LOG IN</h2>
        <div class="inputbox">
          <input type="email" name="login_email" placeholder="  EMAIL">
          <?php
          					 if(isset($_GET['error'])){
          						 if($_GET['error'] == 'invaliduidmail'){
          								 echo '<span>&nbsp&nbsp&nbsp&nbsp*Wrong Mail</span>';
          						 }
          					 } ?>
          <input type="password" name="login_pwd" placeholder="  PASSWORD">
          <?php
						 if(isset($_GET['error'])){
							 if($_GET['error'] == 'wrongpwd'){
                   echo '<span>&nbsp&nbsp&nbsp&nbsp*Wrong Password</span>';
							 }
						 } ?>
        </div>
        <p>FORGET PASSWORD?</p>
        <button type="submit" name="login-submit">LOG IN</button>
      </div>

      <div class="signup hide">
        <h2>SIGN UP</h2>
        <div class="inputbox">
          <input type="text" name="name" placeholder=" FULL NAME" value="<?php echo isset($_GET['name']) ? $_GET['name'] : ''; ?>">
					<?php
					if(isset($_GET['error']))
					{
						if(($_GET['error']) == "invaliduid")
						{
							echo '<span>&nbsp&nbsp&nbsp&nbsp*Name should consist of only alphabets</span>';
						}
					}?>
          <input type="email" name="email" placeholder="  EMAIL" value="<?php echo isset($_GET['email']) ? $_GET['email'] : ''; ?>">
          <?php
					if(isset($_GET['error']))
					{
						if(($_GET['error']) == "invalidmail")
						{
							echo '<span>&nbsp&nbsp&nbsp&nbsp*Enter a valid email</span>';
						}
						else if(($_GET['error']) == "mailtaken")
						{
							echo '<span>&nbsp&nbsp&nbsp&nbsp*Email already taken</span>';
						}
					}?>
          <input type="password" name="pwd" placeholder="  PASSWORD" minlength="8" maxlength="15">
						<?php
						if(isset($_GET['error']))
						{
						 if(($_GET['error']) == "passwordcheck")
						 {
							 echo '<span>&nbsp&nbsp&nbsp&nbsp*Password should consist of only alphabets and numbers</span>';
						 }
						}?>
          <input type="text" name="year" placeholder=" YEAR" value="<?php echo isset($_GET['year']) ? $_GET['year'] : ''; ?>">
          <input type="text" name="date" placeholder=" DEPARTMENT" value="<?php echo isset($_GET['dept']) ? $_GET['dept'] : ''; ?>">
        </div>
        
        <button type='submit' name='signup-submit' >SIGN UP</button>
      </div>

    </div>
    <!-- frontbox -->
  </div>
</form>
<script>
var $loginMsg = $('.loginMsg'),
    $login = $('.login'),
    $signupMsg = $('.signupMsg'),
    $signup = $('.signup'),
    $frontbox = $('.frontbox'),
    $container = $('.container');


  $('#switch1').on('click', function () {
    $loginMsg.toggleClass("visibility");
    $frontbox.addClass("moving");
    $container.addClass("container-size")
    $signupMsg.toggleClass("visibility");

    $signup.toggleClass('hide');
    $login.toggleClass('hide');
  })

  $('#switch2').on('click', function () {
    $loginMsg.toggleClass("visibility");
    $frontbox.removeClass("moving");
    $container.removeClass("container-size");
    $signupMsg.toggleClass("visibility");

    $signup.toggleClass('hide');
    $login.toggleClass('hide');
  })

  </script>
</body>
</html>