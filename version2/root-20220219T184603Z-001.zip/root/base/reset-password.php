<?php
include_once 'includes/dbh.inc.php'
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset Password - Study Perk</title>
<link rel="icon" href="images/logo.png" type="image/ico">
<link href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
	body {
        color: #434343;
		background: #dfe7e9;
		font-family: 'Varela Round', sans-serif;
	}
    .form-control {
		font-size: 16px;
		transition: all 0.4s;
		box-shadow: none;
	}
	.form-control:focus {
        border-color: #5cb85c;
    }
    .form-control, .btn {
        border-radius: 50px;
		outline: none !important;
    }
	.signin-form {
		width: 420px;
    	margin: 0 auto;
		padding: 30px 0;
	}
    .signin-form form {
		border-radius: 5px;
    	margin-bottom: 20px;
        background: #fff;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 40px;
    }
	.signin-form a {
		color: #5cb85c;
	}
	.signin-form h2 {
		text-align: center;
		font-size: 34px;
		margin: 10px 0 15px;
	}
	.signin-form .hint-text {
		color: #999;
		text-align: center;
		margin-bottom: 20px;
	}
	.signin-form .form-group {
		margin-bottom: 20px;
	}
    .signin-form .btn {
        font-size: 18px;
		line-height: 26px;
        font-weight: bold;
		text-align: center;
    }
    .signin-form .small {
        font-size: 13px;
    }
	.signup-btn {
		text-align: center;
		border-color: #5cb85c;
		transition: all 0.4s;
	}
	.signup-btn:hover {
		background: #5cb85c;
		opacity: 0.8;
	}
</style>
</head>
<body>
<div class="signin-form">
    <form action="includes/reset-request.inc.php" method="post">
		<h2>Reset password</h2>
        <p class="hint-text">An e-mail will be sent to you with instructions on how to reset your password</p>
        <div class="form-group">
            	<input type="email" class="form-control input-lg" name="mail" placeholder="Email Address" required="required">
            </div>
        <div class="form-group">
            <button type="submit" name="reset-request-submit" class="btn btn-success btn-lg btn-block signup-btn">Receive Mail</button>
        </div>
    </form>
    <div class="text-center small">Don't have an account? <a href="signup.php">Sign up</a></div>
</div>
</body>
</html>
