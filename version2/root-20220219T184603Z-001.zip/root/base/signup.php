<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign Up - Study Perk</title>
<link rel="icon" href="images/logo.png" type="image/ico">
<link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<style type="text/css">
	body {
		background: #dfe7e9;
		font-family: 'Roboto', sans-serif;
	}
    .form-control {
		font-size: 16px;
		transition: all 0.4s;
		box-shadow: none;
	}
	.form-control:focus {
        border-color: #5cb85c;
    }
    .form-control, .btn {
        border-radius: 50px;
		outline: none !important;
    }
	.signup-form {
		width: 480px;
    	margin: 0 auto;
		padding: 30px 0;
	}
    .signup-form form {
		border-radius: 5px;
    	margin-bottom: 20px;
        background: #fff;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 40px;
    }
	.signup-form a {
		color: #5cb85c;
	}
	.signup-form h2 {
		text-align: center;
		font-size: 34px;
		margin: 10px 0 15px;
	}
	.signup-form .hint-text {
		color: #999;
		text-align: center;
		margin-bottom: 20px;
	}
	.signup-form .form-group {
		margin-bottom: 20px;
	}
    .signup-form .btn {
        font-size: 18px;
		line-height: 26px;
        font-weight: bold;
		text-align: center;
    }
	.signup-btn {
		text-align: center;
		border-color: #5cb85c;
		transition: all 0.4s;
	}
	.signup-btn:hover {
		background: #5cb85c;
		opacity: 0.8;
	}
    .or-seperator {
        margin: 50px 0 15px;
        text-align: center;
        border-top: 1px solid #e0e0e0;
    }
    .or-seperator b {
        padding: 0 10px;
		width: 40px;
		height: 40px;
		font-size: 16px;
		text-align: center;
		line-height: 40px;
		background: #fff;
		display: inline-block;
        border: 1px solid #e0e0e0;
		border-radius: 50%;
        position: relative;
        top: -22px;
        z-index: 1;
    }
    .social-btn .btn {
		color: #fff;
        margin: 10px 0 0 15px;
		font-size: 15px;
		border-radius: 50px;
		font-weight: normal;
		border: none;
		transition: all 0.4s;
    }
	.social-btn .btn:first-child {
		margin-left: 0;
	}
	.social-btn .btn:hover {
		opacity: 0.8;
	}
	.social-btn .btn-primary {
		background: #507cc0;
	}
	.social-btn .btn-info {
		background: #64ccf1;
	}
	.social-btn .btn-danger {
		background: #df4930;
	}
	.social-btn .btn i {
		float: left;
		margin: 3px 10px;
		font-size: 20px;
	}
	.class{
		width: 200px;
	}
	.input-group-addon:last-child {
    border-bottom-right-radius: 20px !important;
    border-top-right-radius: 20px !important;
}
label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: lighter;
    font-size: 16px;
    margin-left: 10px;
	}
	.second{
		margin-left: 25px;
	}
	.cbox{
		margin-left: 10px;
	}
	span{
		color: red;
		font-size: 14px;
	}
</style>
</head>
<body>
<div class="signup-form">
    <form action="includes/signup.inc.php" method="post">
		<h2>Create an Account</h2>
		<p class="hint-text">Sign up with your social media account or email address</p>
		<div class="social-btn text-center">
			<?php  echo $output; ?>
		</div>
		<div class="or-seperator"><b>or</b></div>
        <div class="form-group">
        	<input type="text" class="form-control input-lg" name="uid" placeholder="Username" maxlength="10" minlength="3" required="required" value="<?php echo isset($_GET['uid']) ? $_GET['uid'] : ''; ?>">
					<?php
					if(isset($_GET['error']))
					{
						if(($_GET['error']) == "invaliduid")
						{
							echo '<span>&nbsp&nbsp&nbsp&nbsp*Name should consist of only alphabets</span>';
						}
					}?>
				</div>
		<div class="form-group">
        	<input type="email" class="form-control input-lg" name="mail" placeholder="Email Address" required="required" value="<?php echo isset($_GET['mail']) ? $_GET['mail'] : ''; ?>">
          <?php
					if(isset($_GET['error']))
					{
						if(($_GET['error']) == "invalidmail")
						{
							echo '<span>&nbsp&nbsp&nbsp&nbsp*Enter a valid email</span>';
						}
						else if(($_GET['error']) == "mailtaken")
						{
							echo '<span>&nbsp&nbsp&nbsp&nbsp*Email already taken</span>';
						}
					}?>
				</div>
				<div class="form-group">
							<select name="class" class="form-control input-lg class" required="required">
								<option value="" style="display: none">Class</option>
								<option value="8">Class VIII</option>
								<option value="9">Class IX</option>
								<option value="10">Class X</option>
								<option value="11">Class XI</option>
								<option value="12">Class XII</option>
							</select>
						</div>

			<div class="form-group">
				   <input type="tel" class="form-control input-lg" name="tel" placeholder="Phone No." required="required" value="<?php echo isset($_GET['tel']) ? $_GET['tel'] : ''; ?>">
					 <?php
					 if(isset($_GET['error']))
					 {
					 	if(($_GET['error']) == "invalidphone")
					 	{
					 		echo '<span>&nbsp&nbsp&nbsp&nbsp*Enter a valid Phone no.</span>';
					 	}
					 }?>
			</div>

		<div class="form-group">
            <input type="password" class="form-control input-lg" name="pwd" placeholder="Password" required="required" minlength="8" maxlength="15" data-toggle="password">
						<?php
						if(isset($_GET['error']))
						{
						 if(($_GET['error']) == "passwordcheck")
						 {
							 echo '<span>&nbsp&nbsp&nbsp&nbsp*Password should consist of only alphabets and numbers</span>';
						 }
						}?>
				</div>
		<div class="form-group">
            <input type="password" class="form-control input-lg" name="pwd-repeat" placeholder="Confirm Password" required="required" minlength="8" maxlength="15" data-toggle="password">
						<?php
						if(isset($_GET['error']))
						{
						 if(($_GET['error']) == "passwordrepeatcheck")
						 {
							 echo '<span>&nbsp&nbsp&nbsp&nbsp*Password do not match</span>';
						 }
						}?>
				</div>
		<div class="form-group cbox">
			<input type="checkbox" name="terms" required="required">
			 <label for="terms">Study Perk <a href="#">Privacy Policies</a> applies.</label>
			 <label for="terms" class="second">Study Perk <a href="#">Terms & Condition</a> apply.</label>
		</div>
        <div class="form-group">
            <button type="submit" name="signup-submit" class="btn btn-success btn-lg btn-block signup-btn">Sign Up</button>
        </div>
    </form>
    <div class="text-center">Already have an account? <a href="login.php">Login here</a></div>
</div>
<script type="text/javascript">
	$("#password").password('toggle');
</script>
</body>
</html>
